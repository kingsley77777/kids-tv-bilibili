// 小企鹅动画屋 - Service Worker
const CACHE_NAME = "kids-tv-v1.1";
const ASSETS = ["/", "/index.html"];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS).catch(() => {});
        })
    );
    self.skipWaiting();
});

self.addEventListener("activate", (event) => {
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
            );
        })
    );
    self.clients.claim();
});

self.addEventListener("fetch", (event) => {
    // 对 B站 API 和播放器走网络，对本地资源走缓存
    const url = new URL(event.request.url);
    if (url.hostname.includes("bilibili.com") || url.hostname.includes("api.bilibili.com")) {
        // 网络优先，失败不缓存（B站API数据实时性要求高）
        event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
    } else {
        // 本地资源：缓存优先
        event.respondWith(
            caches.match(event.request).then((cached) => {
                return cached || fetch(event.request).then((response) => {
                    if (response.ok && response.type === "basic") {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(event.request, clone);
                        });
                    }
                    return response;
                });
            })
        );
    }
});
